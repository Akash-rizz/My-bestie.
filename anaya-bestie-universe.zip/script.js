/* ANAYA BESTIE UNIVERSE
   Personalize the text in this CONFIG object. No API key is needed. */
const CONFIG = {
  name: "Anaya",
  title: "Anaya's Universe",
  footer: "Made with friendship, for Anaya ✨",
  letter: `Some friendships make ordinary days a little brighter, and I'm genuinely glad to have you as my bestie.

Thank you for the laughs, the random conversations, the memories, and all the little moments that make friendship special.

No matter how busy life gets, I hope you always remember that you deserve happiness, respect, kindness, and people who appreciate the real you.

Here's to more laughs, more memories, and more legendary bestie moments.`,
  stories: [
    { icon: "✦", title: "How It Began", text: "Two different worlds, one random moment, and now… a friendship worth keeping. (Replace with your story!)" },
    { icon: "☻", title: "Funniest Moments", text: "Inside jokes, weird laughs, and absolutely no sense. (Replace with your moments!)" },
    { icon: "☏", title: "Random Chats", text: "The conversations that make no sense to anyone else." },
    { icon: "☆", title: "Memories Forever", text: "The little moments we'll always keep in our hearts." },
    { icon: "♡", title: "Why You're Amazing", text: "Your kindness, strength, weirdness, and the way you are just you." }
  ],
  memories: [
    { icon: "☁", caption: "Good Times ♡" },
    { icon: "✧", caption: "Our Vibes ♡" },
    { icon: "☾", caption: "Besties Forever" },
    { icon: "✿", caption: "Dreams ♡" }
  ],
  quiz: [
    { q: "Who is more likely to laugh at something completely random?", a: ["You", "Me", "Both equally", "No idea 😂"] },
    { q: "What is the best kind of bestie plan?", a: ["A spontaneous adventure", "Snacks and chatting", "Doing something chaotic", "Any plan together"] },
    { q: "Choose our friendship's unofficial emoji.", a: ["😂", "🫶", "✨", "All of them, obviously"] },
    { q: "What makes a friendship stronger?", a: ["Trust", "Showing up for each other", "Honest conversations", "All of the above"] },
    { q: "What should our next memory be?", a: ["A new adventure", "A legendary laugh", "A wholesome little moment", "Something completely unexpected"] }
  ],
  surprises: [
    "Anaya, never underestimate how much brighter a day can get because you showed up. 💗",
    "Bestie reminder: you deserve kindness, good laughs, peaceful days, and people who cheer for you. ✨",
    "Official universe announcement: your bestie energy has been detected across several galaxies. 🪐",
    "May your snacks be tasty, your worries be lighter, and your laugh be ridiculously contagious. 😂",
    "Some people make memories. Some people become the memory you smile about. Keep being wonderfully you. ♡",
    "Emergency bestie notice: drink some water, stretch a little, and remember you're appreciated. 🌷",
    "If friendship had a constellation, ours would definitely be the one making questionable shapes. ⭐"
  ]
};

const $ = id => document.getElementById(id);
const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
let starTaps = 0, orbTaps = 0, quizIndex = 0, quizAnswers = [], selectedAnswer = null;
let lastSurprise = -1, toastTimer, audio = null;
const starCanvas = $("starfield");
const ctx = starCanvas.getContext("2d");
let stars = [], frame = 0;

function showToast(message) {
  const toast = $("toast");
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove("show"), 2400);
}

function buildStories() {
  const grid = $("storyGrid");
  CONFIG.stories.forEach(item => {
    const card = document.createElement("article");
    card.className = "story-card reveal";
    const icon = document.createElement("div");
    icon.className = "story-icon";
    icon.textContent = item.icon;
    const title = document.createElement("h3");
    title.textContent = item.title;
    const text = document.createElement("p");
    text.textContent = item.text;
    card.append(icon, title, text);
    grid.append(card);
  });
}

function buildMemories() {
  const grid = $("memoryGrid");
  CONFIG.memories.forEach((item, index) => {
    const card = document.createElement("figure");
    card.className = "memory-card reveal";
    const art = document.createElement("div");
    art.className = "memory-art";
    art.textContent = item.icon;
    art.setAttribute("aria-hidden", "true");
    const caption = document.createElement("figcaption");
    caption.textContent = item.caption;
    card.append(art, caption);
    card.tabIndex = 0;
    card.setAttribute("role", "button");
    card.setAttribute("aria-label", `Memory placeholder: ${item.caption}`);
    card.addEventListener("click", () => showToast("Add a real photo using the button below ✨"));
    card.addEventListener("keydown", e => {
      if (e.key === "Enter" || e.key === " ") { e.preventDefault(); card.click(); }
    });
    grid.append(card);
  });
}

function refreshReveals() {
  const elements = document.querySelectorAll(".reveal:not(.visible)");
  if (!("IntersectionObserver" in window) || reduceMotion) {
    elements.forEach(el => el.classList.add("visible"));
    return;
  }
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add("visible");
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.12 });
  elements.forEach(el => observer.observe(el));
}

function resizeCanvas() {
  const dpr = Math.min(window.devicePixelRatio || 1, 1.5);
  starCanvas.width = innerWidth * dpr;
  starCanvas.height = innerHeight * dpr;
  starCanvas.style.width = innerWidth + "px";
  starCanvas.style.height = innerHeight + "px";
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  stars = Array.from({ length: innerWidth < 600 ? 65 : 115 }, () => ({
    x: Math.random() * innerWidth, y: Math.random() * innerHeight,
    r: Math.random() * 1.4 + .25, a: Math.random() * .6 + .2,
    speed: Math.random() * .18 + .025, phase: Math.random() * 6
  }));
}
function drawStars() {
  ctx.clearRect(0, 0, innerWidth, innerHeight);
  stars.forEach(s => {
    const twinkle = .55 + Math.sin(frame * .015 + s.phase) * .35;
    ctx.beginPath();
    ctx.arc(s.x, s.y, s.r, 0, Math.PI * 2);
    ctx.fillStyle = `rgba(228,204,255,${s.a * twinkle})`;
    ctx.fill();
    if (!reduceMotion) {
      s.y -= s.speed;
      if (s.y < -3) { s.y = innerHeight + 3; s.x = Math.random() * innerWidth; }
    }
  });
  frame++;
  if (!reduceMotion && !document.hidden) requestAnimationFrame(drawStars);
}
document.addEventListener("visibilitychange", () => {
  if (!document.hidden && !reduceMotion) requestAnimationFrame(drawStars);
});

function openLetter() {
  $("envelope").classList.add("open");
  $("envelope").setAttribute("aria-expanded", "true");
  $("letterPaper").classList.add("open");
  $("letterPaper").setAttribute("aria-hidden", "false");
  $("openLetter").setAttribute("aria-pressed", "true");
  $("letterPaper").querySelector(".close-letter").focus({preventScroll:true});
}
function closeLetter() {
  $("letterPaper").classList.remove("open");
  $("letterPaper").setAttribute("aria-hidden", "true");
  $("envelope").classList.remove("open");
  $("envelope").setAttribute("aria-expanded", "false");
  $("openLetter").setAttribute("aria-pressed", "false");
  $("openLetter").focus({preventScroll:true});
}

function renderQuiz() {
  const total = CONFIG.quiz.length;
  $("quizResult").hidden = true;
  $("quizQuestion").hidden = false;
  $("quizOptions").hidden = false;
  $("quizProgressText").textContent = `QUESTION ${quizIndex + 1} / ${total}`;
  $("quizProgressPct").textContent = `${Math.round((quizIndex + 1) / total * 100)}%`;
  $("progressBar").style.width = `${(quizIndex + 1) / total * 100}%`;
  $("quizQuestion").textContent = CONFIG.quiz[quizIndex].q;
  $("quizOptions").replaceChildren();
  selectedAnswer = null;
  $("quizNext").disabled = true;
  $("quizNext").textContent = quizIndex === total - 1 ? "See our result ✨" : "Next question →";
  CONFIG.quiz[quizIndex].a.forEach((answer, i) => {
    const button = document.createElement("button");
    button.className = "quiz-option";
    button.innerHTML = `<span class="option-symbol">${["✧","♡","☼","✦"][i % 4]}</span>`;
    const label = document.createElement("span");
    label.textContent = answer;
    button.append(label);
    button.addEventListener("click", () => {
      selectedAnswer = i;
      $("quizOptions").querySelectorAll("button").forEach(b => b.classList.remove("selected"));
      button.classList.add("selected");
      $("quizNext").disabled = false;
    });
    $("quizOptions").append(button);
  });
}
function finishQuiz() {
  $("quizQuestion").hidden = true;
  $("quizOptions").hidden = true;
  $("quizNext").hidden = true;
  $("quizProgressText").textContent = "BESTIE QUIZ COMPLETE";
  $("quizProgressPct").textContent = "100%";
  $("progressBar").style.width = "100%";
  $("quizSecretStatus").textContent = "Unlocked ✨";
  $("secretUnlock").hidden = false;
  $("secretUnlock").textContent = "🌟 Secret unlocked: Anaya, you make this little universe more colourful just by being part of it. Keep being your wonderfully unique self. ♡";
  const result = $("quizResult");
  result.hidden = false;
  result.textContent = "✨ Official result: 100% bestie vibes. The answers were all about having fun — because this quiz has no wrong answers when friendship is involved. Your secret message has been unlocked below!";
}
$("quizNext").addEventListener("click", () => {
  if (selectedAnswer === null) return;
  quizAnswers.push(selectedAnswer);
  if (quizIndex < CONFIG.quiz.length - 1) { quizIndex++; renderQuiz(); }
  else finishQuiz();
});
$("quizRestart").addEventListener("click", () => {
  quizIndex = 0; quizAnswers = []; $("quizNext").hidden = false; renderQuiz();
});

function surprise() {
  if (CONFIG.surprises.length === 0) return;
  let index = Math.floor(Math.random() * CONFIG.surprises.length);
  if (CONFIG.surprises.length > 1 && index === lastSurprise) index = (index + 1) % CONFIG.surprises.length;
  lastSurprise = index;
  $("surpriseMessage").textContent = CONFIG.surprises[index];
  $("surpriseMessage").animate?.([{opacity:.35,transform:"translateY(5px)"},{opacity:1,transform:"translateY(0)"}], {duration:350,easing:"ease-out"});
}
async function copySurprise() {
  const text = $("surpriseMessage").textContent;
  try {
    await navigator.clipboard.writeText(text);
    showToast("Message copied! Share the good vibes 💗");
  } catch {
    const area = document.createElement("textarea");
    area.value = text; area.style.position = "fixed"; area.style.opacity = "0";
    document.body.append(area); area.select();
    const ok = document.execCommand("copy"); area.remove();
    showToast(ok ? "Message copied! 💗" : "Select and copy the message manually.");
  }
}

function starSecret() {
  starTaps++;
  $("starCount").textContent = `${Math.min(starTaps,3)} / 3`;
  if (starTaps >= 3) {
    $("secretUnlock").hidden = false;
    $("secretUnlock").textContent = "💫 Secret star message: Even on an ordinary day, you can be somebody's favourite plot twist. Keep shining, Anaya. ♡";
    showToast("Secret star message unlocked! ✨");
  } else showToast(`The star is waking up… ${3-starTaps} more tap(s)!`);
}
function orbSecret() {
  orbTaps++;
  $("orbCount").textContent = `${Math.min(orbTaps,5)} / 5`;
  $("friendshipOrb").animate?.([{transform:"scale(1)"},{transform:"scale(1.12) rotate(8deg)"},{transform:"scale(1)"}],{duration:450});
  if (orbTaps >= 5) {
    $("secretUnlock").hidden = false;
    $("secretUnlock").textContent = "🪐 Cosmic secret: Friendship is a constellation made from tiny moments. Thanks for being part of this one, Anaya. ♡";
    showToast("Cosmic sparkle unlocked! 🪐");
  } else showToast("Cosmic energy rising… ✨");
}

$("openLetter").addEventListener("click", openLetter);
$("envelope").addEventListener("click", openLetter);
$("closeLetter").addEventListener("click", closeLetter);
$("surpriseButton").addEventListener("click", surprise);
$("anotherSurprise").addEventListener("click", surprise);
$("copyMessage").addEventListener("click", copySurprise);
$("secretStar").addEventListener("click", starSecret);
$("secretOrb").addEventListener("click", orbSecret);
$("friendshipOrb").addEventListener("click", orbSecret);
$("musicButton").addEventListener("click", () => {
  if (!audio) {
    showToast("Music is optional — add assets/music.mp3 and enable it in script.js.");
    return;
  }
  if (audio.paused) audio.play().then(() => {
    $("musicLabel").textContent = "Music on"; $("musicButton").setAttribute("aria-pressed","true");
  }).catch(() => showToast("Your browser couldn't play that audio file."));
  else { audio.pause(); $("musicLabel").textContent = "Music off"; $("musicButton").setAttribute("aria-pressed","false"); }
});

$("photoUpload").addEventListener("change", event => {
  const files = Array.from(event.target.files || []).filter(file => file.type.startsWith("image/"));
  if (!files.length) return;
  files.forEach(file => {
    const url = URL.createObjectURL(file);
    const card = document.createElement("figure");
    card.className = "memory-card";
    const img = document.createElement("img");
    img.src = url; img.alt = `Photo memory: ${file.name}`;
    const caption = document.createElement("figcaption");
    caption.textContent = file.name.replace(/\.[^.]+$/, "").replace(/[-_]/g," ");
    card.append(img, caption);
    $("memoryGrid").prepend(card);
  });
  showToast(`${files.length} photo(s) added for this session. They stay on this device.`);
  event.target.value = "";
});

$("menuToggle").addEventListener("click", () => {
  const nav = $("navigation");
  const isOpen = nav.classList.toggle("open");
  $("menuToggle").setAttribute("aria-expanded", String(isOpen));
  $("menuToggle").textContent = isOpen ? "×" : "☰";
});
$("navigation").querySelectorAll("a").forEach(link => link.addEventListener("click", () => {
  $("navigation").classList.remove("open");
  $("menuToggle").setAttribute("aria-expanded","false");
  $("menuToggle").textContent = "☰";
}));

$("letterText").textContent = CONFIG.letter;
$("musicLabel").textContent = "Music off";
buildStories();
buildMemories();
resizeCanvas();
drawStars();
refreshReveals();
window.addEventListener("resize", resizeCanvas);
